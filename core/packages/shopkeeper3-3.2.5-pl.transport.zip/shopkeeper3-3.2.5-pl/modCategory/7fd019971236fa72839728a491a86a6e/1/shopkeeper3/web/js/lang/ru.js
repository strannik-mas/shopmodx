
var langTxt = new Array();

langTxt['delAll'] = "Очистить корзину";
langTxt['select'] = "Вы выбрали:";
langTxt['empty'] = "Пусто";
langTxt['confirm'] = "Вы уверены?";
langTxt['continue'] = "Да";
langTxt['yes'] = "Да";
langTxt['cancel'] = "Отмена";
langTxt['cookieError'] = "Для нормальной работы в браузере должны быть включены cookies.";
langTxt['delete'] = "Удалить";
langTxt['delGoods'] = "Удалить товар";
langTxt['goods'] = "товар";
langTxt['count'] = "Кол-во";
langTxt['sumTotal'] = "Общая сумма:";
langTxt['executeOrder'] = "Оформить заказ";
langTxt['changeCount'] = "Изменить количество";
langTxt['addedToCart'] = "Товар добавлен в корзину";

langTxt['error_jqVersion'] = "Для работы Shopkeeper необходим jQuery версии 1.7+. Вы используете: ";
