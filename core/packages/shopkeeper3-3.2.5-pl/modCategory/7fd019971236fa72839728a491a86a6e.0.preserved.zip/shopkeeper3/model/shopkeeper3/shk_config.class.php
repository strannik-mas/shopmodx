<?php
class shk_config extends xPDOSimpleObject {}